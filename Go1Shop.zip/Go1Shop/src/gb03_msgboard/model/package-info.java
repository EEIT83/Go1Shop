/**
 * 
 */
/**
 * @author Student
 *
 */
package gb03_msgboard.model;