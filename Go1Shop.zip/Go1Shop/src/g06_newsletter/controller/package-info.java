/**
 * 
 */
/**
 * @author Student
 *
 */
package g06_newsletter.controller;