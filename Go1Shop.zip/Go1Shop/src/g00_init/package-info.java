/**
 * 
 */
/**
 * @author Student
 *
 */
package g00_init;